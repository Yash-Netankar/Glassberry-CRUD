const { getProduct, getProducts } = require("../../actions/Products/get");
const ApiHTTPResponse = require("../../utils/httpResponse");


// all products
const getAllProducts = async (req, res) => {
    try {
        const todos = await getProducts();
        if (todos && todos.length > 0) {
            const response = ApiHTTPResponse(200, todos, "Products fetched successfuly");
            return res.status(200).json(response);
        }
        else {
            if (todos.length <= 0) {
                const response = ApiHTTPResponse(404, [], "No products to show");
                return res.status(404).json(response);
            }
            else {
                const response = ApiHTTPResponse(400, [], "Failed to fetch todos");
                return res.status(400).json(response);
            }
        }
    }
    catch (error) {
        console.log(error.message)
        const response = ApiHTTPResponse(500, [], "Failed to fetch products");
        return res.status(500).json(response);
    }
};



// single product
const getSingleProduct = async (req, res) => {
    try {
        let { id } = req.params;
        if (!id) {
            const response = ApiHTTPResponse(404, [], "This product is not available");
            return res.status(404).json(response);
        }
    
        const product = await getProduct(id);
        if (product) {
            const response = ApiHTTPResponse(200, product, "Products fetched successfuly");
            return res.status(200).json(response);
        }
        else {
            const response = ApiHTTPResponse(400, [], "Failed to fetch todos");
            return res.status(400).json(response);
        }
    }
    catch (error) {
        console.log(error.message);
        const response = ApiHTTPResponse(500, [], "Unexpected error occurred");
        return res.status(500).json(response);
    }
}


module.exports = {getSingleProduct, getAllProducts}
