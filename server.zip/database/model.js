const mongoose = require("mongoose");

// Todo Schema
const ProductSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    features: {
        type: [String],
        required: true
    },
    images: {
        type: [String],
    },
    category: {
        category_id: {
            type: String,
            required: true
        },
        category_name: {
            type: String,
            required: true
        }
    },
    sub_category: {
        category_id: {
            type: String,
            required: true
        },
        sub_category_name: {
            type: String,
        }
    },
    brand: {
        type: String,
    }
},
    { timestamps: true }
);


const Product = mongoose.model("product", ProductSchema);

module.exports = { Product };