import {url} from '../utils/Urls';
import axios from 'axios'

export const getProducts = async() => {
  try {
    const res = await axios.get(url.getProducts);
    return res.data.data
  }
  catch (error) {
    console.log(error)
    return []
  }
}

export const getProduct = async(id: any) => {
  try {
    const res = await axios.get(`${url.getProduct}/${id}`)
    return res.data
  } 
  catch (error) {
    console.log(error)
  }
}

