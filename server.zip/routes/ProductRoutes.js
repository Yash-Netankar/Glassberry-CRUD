const { AddProduct } = require("../controllers/Products/addProduct");
const { DeleteProduct } = require("../controllers/Products/deleteProduct");
const { EditProduct } = require("../controllers/Products/editProduct");
const { getAllProducts, getSingleProduct } = require("../controllers/Products/getProduct");
const ApiHTTPResponse = require("../utils/httpResponse");
const express = require("express");
const ProductRoutes = express.Router();


// get all Products
ProductRoutes.get("/getProducts", getAllProducts);

// get single Product
ProductRoutes.get("/getProduct/:id", getSingleProduct);

// add Product
ProductRoutes.post("/addProduct", AddProduct);

//edit Product
ProductRoutes.patch("/editProduct", EditProduct);

//delete Product
ProductRoutes.delete("/deleteProduct/:id", DeleteProduct);

module.exports = ProductRoutes;