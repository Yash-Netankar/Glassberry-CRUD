const {Product} = require("../../database/model");

const getProducts = async() => {
    const products = await Product.find({}).lean();
    return products;
}

const getProduct = async(id) => {
    const product = await Product.findOne({_id: id}).lean();
    return product;
}

module.exports = {getProduct, getProducts}