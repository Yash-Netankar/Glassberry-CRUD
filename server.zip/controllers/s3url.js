const AWS = require("aws-sdk");
const {getUniqueCode} = require("../utils/getUniqueCode");
const { Product } = require("../database/model");

const s3 = new AWS.S3({
    signatureVersion: "v4",
    region: "ap-south-1",
    bucket: process.env.S3_BUCKET
});


const createS3PreSignedUrl = async (req, res) => {
    try {
        const fileName = req.body.fileName;
        const productId = req.body.productId;
        const type = 'putObject';
        let code = getUniqueCode(8);
        // if (!code) {
        //     return res.status(400).json({ success: false, msg: "Cannot get unique code for the file" })
        // }

        await Product.findByIdAndUpdate({_id: productId},
            {"$addToSet": {"images": `${productId}_${fileName}`}})

        let s3key = `${productId}/${productId}_${fileName}`;
        let bucket = "glassbery-products"
        const params = {
            Bucket: bucket,
            Key: s3key,
            ContentType: "image/jpeg, image/png, image/jpg",
            Expires: 30000,
            ACL: 'public-read',
        }
        const URL = await s3.getSignedUrl(type, params);
        let link = `https://s3.console.aws.amazon.com/s3/object/${bucket}?region=us-east-1&prefix=${s3key}`;

        return res.json({ success: true, msg: "Url generated", url: URL, file:link })
    }
    catch (error) {
        console.log(error)
        return res.json({ success: false, error: "No Url generated"})
    }
}

module.exports = {createS3PreSignedUrl}