const { Delete } = require("../../actions/Products/delete");
const { CheckMissingFields } = require("../../utils/checkMissingFields");
const ApiHTTPResponse = require("../../utils/httpResponse");

const DeleteProduct = async(req, res) => {
    try {
        const {id} = req.params;
        const requiredFields = ["id"];
        const checkRes = CheckMissingFields(requiredFields, {id});
        if (checkRes) {
            const response = ApiHTTPResponse(400, [], `${checkRes.join(",")} missing`);
            return res.status(400).json(response);
        }

        await Delete(id);
        const response = ApiHTTPResponse(200, null, "Product deleted successfuly");
        return res.status(200).json(response);
    }
    catch (error) {
        console.log(error.message);
        const response = ApiHTTPResponse(500, [], "Failed to delete product, Internal server error occurred");
        return res.status(500).json(response);
    }
}

module.exports = {DeleteProduct}