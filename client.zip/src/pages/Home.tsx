import React, { useEffect, useState } from 'react'
import EnhancedTable from '../MyComponents/Table'
import { getProducts } from '../api/getProduct';
import { deleteProduct } from '../api/deleteProduct';

const Home = () => {
  const [data, setData] = useState([]) as any;

  const fetchProducts = async() => {
    try {
      const res = await getProducts();
      setData(res)
    }
    catch (error) {
      alert("Unexpected Error Occurred")
    }
  }

  const deleteProductFromDb = async(id: any) => {
    await deleteProduct(id)
    setData(data.filter((p: any) => p._id.toString() !== id))
  }

  useEffect(() => {
    fetchProducts();
  }, [])

  if(data.length <= 0){
    return <h5 className='text-center'>No products to show</h5>
  }
  return (
    <EnhancedTable products={data} deleteProductFromDb={deleteProductFromDb}/>
  )
}

export default Home