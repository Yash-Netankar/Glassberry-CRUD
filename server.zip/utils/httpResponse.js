const ApiHTTPResponse = (status, data, msg) => {

    switch (status) {
        case 200:
            return {
                statusCode: status,
                data,
                msg,
                apiMsg: "OK",
                success: true
            }

        case 201:
            return {
                statusCode: status,
                data,
                msg,
                apiMsg: "CREATED",
                success: true
            }

        case 204:
            return {
                statusCode: status,
                data,
                msg,
                apiMsg: "NO CONTENT",
                success: true
            }

        case 400:
            return {
                statusCode: status,
                data,
                msg,
                apiMsg: "BAD REQUEST",
                success: false
            }

        case 401:
            return {
                statusCode: status,
                data,
                msg,
                apiMsg: "Unauthorised",
                success: false
            }

        case 404:
            return {
                statusCode: status,
                data,
                msg,
                apiMsg: "NOT FOUND",
                success: false
            }

        case 409:
            return {
                statusCode: status,
                data,
                msg,
                apiMsg: "DUPLICATE ENTRY",
                success: false
            }

        case 500:
            return {
                statusCode: status,
                data,
                msg,
                apiMsg: "INTERNAL SERVER ERROR",
                success: false
            }

        default:
            return {
                statusCode: 500,
                data: [],
                msg: "",
                apiMsg: "INTERNAL SERVER ERROR",
                success: false
            }
    }
}

module.exports = ApiHTTPResponse