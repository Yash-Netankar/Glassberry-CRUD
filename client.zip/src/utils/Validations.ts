import * as Yup from 'yup';


const ValidateAddProduct = Yup.object().shape({
    name: Yup.string().required("Product Name is required"),
    description: Yup.string().required("Please provide product description"),
    features: Yup.string().min(1).required("Please provide product description"),
    brand: Yup.string().required("Please specify product brand"),
    category: Yup.mixed().test(
        "required",
        "Category is required",
        (value) => value !== ""
    ),
    sub_category: Yup.mixed().test(
        "required",
        "Sub Category is required",
        (value) => value !== ""
    ),
});

export default ValidateAddProduct