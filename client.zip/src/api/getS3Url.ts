import axios from 'axios'
import { url } from '../utils/Urls'

const getUrl = async(fileName: any, productId: any) => {
    try {
        const res = await axios.post(`${url.getUrl}`, {fileName, productId});
        return res.data
    }
    catch (error) {
        console.log(error)
    }
}

export default getUrl