import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { getProduct } from '../api/getProduct';
import ValidateAddProduct from '../utils/Validations';
import warehouse from '../data/warehouse';
import { Button } from '@mui/material';
import editProduct from '../api/editProduct';
import { features } from 'process';
import getUrl from '../api/getS3Url';
import axios from 'axios'

const EditProduct = () => {
  const params = useLocation();
  const navigate = useNavigate();

  const [subCategories, setSubCategories] = useState([]) as any;

  const [product, setProduct] = useState({
    name: "",
    description: "",
    brand: "",
    features: "",
    images: []
  });

  const [category, setCategory] = useState({
    category: { category_id: "", category_name: "" },
    sub_category: { category_id: "", sub_category_name: "" }
  }) as any;

  const handleChange = (e: any) => {
    const { name, value } = e.target
    setProduct((prev: any) => {
      return {
        ...prev,
        [name]: value
      }
    })
  }

  const handleCategory = (e: any) => {
    const { name, value } = e.target;
    if (!e.target.value || e.target.value == "") {
      setSubCategories([]);
      return
    }
    else if (name == "category" || name == "sub_category") {
      const id = value.split("_")[0];
      const category_name = value.split("_")[1];
      const objToUpdate: any = { category_id: id }
      // update category
      if (name == "category") {
        objToUpdate.category_name = category_name
        let index = warehouse.categories.findIndex((category: any) => category.category_id == id)
        setSubCategories(warehouse.categories[index]["sub_categories"]);
      }
      // update sub-category
      else {
        objToUpdate.sub_category_name = category_name
        const category_index = warehouse.categories.findIndex((c: any) => c.category_id == category.category.category_id)
        setSubCategories(warehouse.categories[category_index]["sub_categories"]);
      }

      // update category state
      setCategory((prev: any) => {
        return {
          ...prev,
          [name]: objToUpdate
        }
      })
    }
  }

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    let data = { ...product, ...category, id: params.state.id }

    try {
      ValidateAddProduct.validate(data)
        .then(async (res) => {
          const response = await editProduct(res);
          if (response.success) {
            navigate("/", { replace: true })
          }
        })
        .catch(err => console.log(err.message))
    } catch (error) {
      console.log(error)
    }
  }

  const handleImage = async (e: any) => {
    try {
      let { id, name } = e.target;
      id = parseInt(id);
      const ext = e.target.files[0].name.split(".").pop();

      const res = await getUrl(e.target.name + ".jpeg", params.state.id);

      if (res?.success) {
        await axios(
          res.url,
          {
            method: "put",
            data: e.target.files[0],
            headers: { "Content-Type": "image/jpeg, image/png, image/jpg" }
          }
        )
      }
    }
    catch (error) {
      console.log(error)
    }
  }


  useEffect(() => {
    const fetchProduct = async () => {
      try {
        if (params.state.id) {
          const resp = await getProduct(params.state.id);
          if (resp?.success) {
            let data = resp.data;
            setProduct((prev: any) => {
              return {
                ...prev,
                _id: data._id,
                name: data.name,
                description: data.description,
                features: data.features.join(" "),
                brand: data.brand,
                images: data.images
              }
            });

            setCategory((prev: any) => {
              return {
                ...prev,
                category: data.category,
                sub_category: data.sub_category
              }
            })

            const index = warehouse.categories.findIndex((c: any) => c.category_id == data.category.category_id)
            setSubCategories(warehouse.categories[index]?.sub_categories)
          }
        }
      }
      catch (error) {
        console.log(error)
      }
    };

    fetchProduct();
  }, [])

  return (
    <div className="container mt-5 edit-page">
      <h5 className='text-center'>Edit Your Product</h5>
      <form className='col-12 col-md-8 m-auto border border-1 p-4 shadow' onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="product_name" className="form-label">Product Name</label>
          <input type="text" name='name' value={product.name} className="form-control" id="product_name" aria-describedby="name" onChange={handleChange} />
        </div>

        <div className="mb-3">
          <label htmlFor="product_desc" className="form-label">Description</label>
          <input type="text" className="form-control" name='description' value={product.description} id="product_desc" onChange={handleChange} />
        </div>

        <div className="mb-4">
          <label htmlFor="product_features" className="form-label">Features</label>
          <input type="text" className="form-control" id="product_features" name='features' onChange={handleChange} value={product.features} />
        </div>

        <div className="mb-4">
          <label htmlFor="product_brand" className="form-label">Brand</label>
          <input type="text" className="form-control" id="product_brand" name='brand' value={product.brand} onChange={handleChange} />
        </div>

        <label htmlFor="product_category" className="form-label">Product Category</label>
        <select className="form-select mb-4" aria-label="Product Category" id='category' onChange={handleCategory} name='category' value={`${category.category.category_id}_${category.category.category_name}`}>
          <option value={""} key={12345}>Select Product Category</option>
          {
            warehouse.categories.map((category: any) => <option value={`${category.category_id}_${category.category_name}`} key={category.category_id}>{category.category_name}</option>)
          }
        </select>

        <label htmlFor="sub_category" className="form-label">Sub-Category</label>
        {
          subCategories.length > 0 &&
          <select className="form-select mb-4" aria-label="Product Sub-Category" disabled={subCategories.length <= 0} onChange={handleCategory} name='sub_category' value={`${category.sub_category.category_id}_${category.sub_category.sub_category_name}`}>
            <option selected value={""} key={123456}>Sub-Category</option>
            {
              subCategories.map((category: any) => <option value={`${category.category_id}_${category.sub_category_name}`} key={category.category_id}>{category.sub_category_name}</option>)
            }
          </select>
        }

        <div className="mt-5 edit-image-section">
          <div>
            <label htmlFor="0">
              <img src={`https://glassbery-products.s3.ap-south-1.amazonaws.com/${params.state.id}/${product.images[0]}`} alt="product image 1" />
            </label>
            <input type="file" id={'0'} onChange={handleImage} name='image1' accept='image/*'/>
          </div>

          <div>
            <label htmlFor="1">
              <img src={`https://glassbery-products.s3.ap-south-1.amazonaws.com/${params.state.id}/${product.images[1]}`} alt="product image 2" />
            </label>
            <input type="file" id={'1'} onChange={handleImage} name='image2' accept='image/*'/>
          </div>

          <div>
            <label htmlFor="2">
              <img src={`https://glassbery-products.s3.ap-south-1.amazonaws.com/${params.state.id}/${product.images[2]}`} alt="product image 3" />
            </label>
            <input type="file" id={'2'} onChange={handleImage} name='image3' accept='image/*'/>
          </div>
        </div>

        <Button variant="contained" type='submit'>Save Product</Button>
      </form>
    </div>
  )
}

export default EditProduct