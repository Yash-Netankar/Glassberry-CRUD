import React, { useState } from 'react';
import Button from '@mui/material/Button';
import DeleteIcon from '@mui/icons-material/Delete';
import AttachFileIcon from '@mui/icons-material/AttachFile';
import Stack from '@mui/material/Stack';
import { useLocation, useNavigate } from 'react-router-dom'
import getUrl from '../api/getS3Url';
import axios from 'axios'

export function AddImages() {
    const params = useLocation();
    const navigate = useNavigate();
    const [isUploading, setisUploading] = useState(false) as any;

    const handleFile = async (e: any) => {
        try {
            const res = await getUrl(e.target.name + ".jpeg", params.state.productId);
            if (res?.success) {
                await axios(
                    res.url,
                    {
                        method: "put",
                        data: e.target.files[0],
                        headers: { "Content-Type": "image/jpeg, image/png, image/jpg" }
                    }
                )
            }
        }
        catch (error) {
            console.log(error)
        }
    }

    if (!params.state.productId) {
        return <h1 className='text-center'>No Product Found</h1>
    }

    else {
        return (
            <>
                <Stack justifyContent={"space-around"} direction="row" mt={5} spacing={2} px={5}>
                    <input
                        type="file"
                        name='image1'
                        onChange={handleFile}
                        disabled={isUploading}
                        accept='image/*'
                    />
                    <input
                        type="file"
                        name='image2'
                        onChange={handleFile}
                        disabled={isUploading}
                        accept='image/*'
                    />

                    <input
                        type="file"
                        name='image3'
                        onChange={handleFile}
                        disabled={isUploading}
                        accept='image/*'
                    />
                </Stack>
                <Stack mt={5} alignItems={"center"} onClick={() => navigate("/", {replace:true})}>
                    <Button variant='contained'>Done</Button>
                </Stack>
            </>
        );
    }
}

export default AddImages