import React from 'react';
import { Routes, Route } from "react-router-dom"
import Home from './pages/Home';
import AddProduct from './pages/AddProduct';
import EditProduct from './pages/EditProduct';
import Navbar from './MyComponents/Navbar'
import AddImages from './pages/AddImages';
import ViewProduct from './pages/ViewProduct';
import "./styles/main.css"

function App() {
  return <>
    <Navbar/>
    <Routes>
      <Route index path='/' element={<Home />}/>
      <Route path='/addProduct' element={<AddProduct />}/>
      <Route path='/EditProduct' element={<EditProduct />}/>
      <Route path='/AddImages' element={<AddImages />}/>
      <Route path='/ViewProduct' element={<ViewProduct />}/>
  </Routes >
  </>
}

export default App;
