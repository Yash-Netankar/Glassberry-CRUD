const {Product} = require("../../database/model");

const add = async(product_details) => {
    const product = new Product({...product_details});
    const res = await product.save();
    return res._id
}

module.exports = {add}