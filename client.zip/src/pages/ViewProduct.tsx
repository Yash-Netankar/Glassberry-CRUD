import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom'
import { getProduct } from '../api/getProduct';

const ViewProduct = () => {
    const params = useLocation();
    const [data, setData] = useState({
        _id: "",
        name: "",
        description: "",
        features: [],
        images: [],
        category: { category_name: "" },
        sub_category: { sub_category_name: "" },
        brand: ""
    });

    useEffect(() => {
        const fetchProduct = async () => {
            try {
                if (params.state.id) {
                    const resp = await getProduct(params.state.id);
                    if (resp?.success) {
                        setData(resp.data)
                    }
                }
            }
            catch (error) {
                console.log(error)
            }
        };

        fetchProduct();
    }, [])

    return (
        <div className="row py-2">

            <section className='img-section col-12 col-md-6 col-lg-5'>
                {
                    data.images.length > 0 ?
                        <div id="carouselExampleIndicators" className="carousel slide" data-bs-ride="carousel">
                            <div className="carousel-indicators">
                                {
                                    data.images.map((image, index) => {
                                        return <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to={`${index}`} className={index==0 ? "active" : "not-active"} aria-current="true" aria-label={`Slide ${index}`}></button>
                                    })
                                }
                            </div>
                            <div className="carousel-inner">
                                {
                                    data.images.map((image, index) => <div className={index == 0 ? `carousel-item active` : `carousel-item`}>
                                        <img src={`https://glassbery-products.s3.ap-south-1.amazonaws.com/${params.state.id}/${image}`} className="d-block w-100" alt={`productImage${index}`} />
                                    </div>)
                                }
                            </div>
                            <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                <span className="carousel-control-prev-icon bg-dark" aria-hidden="true"></span>
                                <span className="visually-hidden">Previous</span>
                            </button>
                            <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                <span className="carousel-control-next-icon bg-dark" aria-hidden="true"></span>
                                <span className="visually-hidden">Next</span>
                            </button>
                        </div>
                        :
                        <h6>Images not found</h6>
                }
            </section>

            <section className='col-12 col-md-6 col-lg-5'>
                <h3 className='text-center'>Details</h3>
                <h4>{data.name}</h4>
                <p style={{ textAlign: "justify" }}>{data.description}</p>
                <h6>Features: </h6>
                <p>{data.features.join(",")}</p>
                <h6>Category: </h6>
                <p>{data.category?.category_name} | {data.sub_category?.sub_category_name}</p>
                <h6>Brand: </h6>
                <p>{data.brand}</p>
            </section>
        </div>
    )
}

export default ViewProduct