import {url} from '../utils/Urls';
import axios from 'axios'

const addProduct = async(data: any) => {
  try {
    const res = await axios.post(url.addProduct, {data})
    return res.data
  }
  catch (error) {
    console.log(error)
  }
}

export default addProduct