const { edit } = require("../../actions/Products/edit");
const { CheckMissingFields } = require("../../utils/checkMissingFields");
const ApiHTTPResponse = require("../../utils/httpResponse");

const EditProduct = async(req, res) => {
    const requiredFields = ["_id"];
    const checkRes = CheckMissingFields(requiredFields, req.body.data);
    if (checkRes) {
        const response = ApiHTTPResponse(400, [], `${checkRes.join(",")} missing`);
        return res.status(400).json(response);
    }

    try {
        await edit(req.body.data);
        const response = ApiHTTPResponse(201, null, "Product updated successfuly");
        return res.status(201).json(response);
    }
    catch (error) {
        console.log(error.message);
        const response = ApiHTTPResponse(500, [], "Failed to update the product details. Internal server error occurred");
        return res.status(500).json(response);
    }
}

module.exports = {EditProduct}