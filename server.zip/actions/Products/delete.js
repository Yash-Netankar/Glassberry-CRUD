const {Product} = require("../../database/model");

const Delete = async(id) => {
    return await Product.findOneAndDelete({_id: id});
}

module.exports = {Delete}