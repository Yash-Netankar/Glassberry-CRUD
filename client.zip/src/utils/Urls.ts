const baseUrl = process.env.REACT_APP_NODE_ENV == "dev" ? "http://localhost:5000" : "";

export const url = {
    // products
    addProduct: `${baseUrl}/product/addProduct`,
    editProduct: `${baseUrl}/product/editProduct`,
    deleteProduct: `${baseUrl}/product/deleteProduct`,
    getProduct: `${baseUrl}/product/getProduct`,
    getProducts: `${baseUrl}/product/getProducts`,

    // s3 presigned url
    getUrl: `${baseUrl}/s3/url`
}