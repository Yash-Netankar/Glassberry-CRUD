const express = require("express");
const router = express.Router();
const {createS3PreSignedUrl} = require("../controllers/s3url");

router.post("/url", createS3PreSignedUrl);

module.exports = {router}