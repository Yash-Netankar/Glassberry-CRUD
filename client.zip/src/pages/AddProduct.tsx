import { useState } from 'react'
import warehouse from '../data/warehouse'
import { Button } from '@mui/material';
import ValidateAddProduct from '../utils/Validations'
import addProduct from '../api/addProduct';
import {useNavigate} from 'react-router-dom';

const AddProduct = () => {
    const navigate = useNavigate();

    const [subCategories, setSubCategories] = useState([]) as any;

    const [product, setProduct] = useState({
        name:"",
        description:"",
        brand: "",
        features: ""
    });

    const [category, setCategory] = useState({
        category: {category_id: "", category_name:""},
        sub_category: {category_id: "", sub_category_name:""}
    }) as any;


    const handleChange = (e: any) => {
        const {name, value} = e.target
        setProduct(prev => {
            return {
                ...prev,
                [name] : value
            }
        })
    }

    const handleCategory = (e: any) => {
        const {name, value} = e.target;
        if(!e.target.value || e.target.value==""){
            setSubCategories([]);
            return
        }
        else if(name == "category" || name == "sub_category"){
            const id = value.split("_")[0];
            const category_name = value.split("_")[1];
            const objToUpdate:any = {category_id: id}
            // update category
            if(name=="category"){
                objToUpdate.category_name = category_name
                let index = warehouse.categories.findIndex((category: any) => category.category_id == id)
                setSubCategories(warehouse.categories[index]["sub_categories"]);
            }
             // update sub-category
            else{
                objToUpdate.sub_category_name = category_name
                const category_index = warehouse.categories.findIndex((c: any) => c.category_id == category.category.category_id)
                setSubCategories(warehouse.categories[category_index]["sub_categories"]);
            }

            // update category state
            setCategory((prev: any) => {
                return {
                    ...prev,
                    [name] : objToUpdate
                }
            })
        }
    }

    const handleSubmit = async(e: any) => {
        e.preventDefault();
        let data = {...product, ...category}

        try {
            ValidateAddProduct.validate(data)
            .then(async(res)=> {
                const response = await addProduct(res);
                if(response.success){
                    navigate("/AddImages", {replace:true ,state: {productId: response.data.productId}})
                }
            })
            .catch(err=>console.log(err.message))
        } catch (error) {
            console.log(error)
        }
    }


    return (
        <div className="container mt-5">
            <h5 className='text-center'>Add a Product</h5>
            <form className='col-12 col-md-8 m-auto border border-1 p-4 shadow' onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label htmlFor="product_name" className="form-label">Product Name</label>
                    <input type="text" name='name' value={product.name} className="form-control" id="product_name" aria-describedby="name" onChange={handleChange}/>
                </div>

                <div className="mb-3">
                    <label htmlFor="product_desc" className="form-label">Description</label>
                    <input type="text" className="form-control" name='description' value={product.description} id="product_desc" onChange={handleChange}/>
                </div>

                <div className="mb-4">
                    <label htmlFor="product_features" className="form-label">Features</label>
                    <input type="text" className="form-control" id="product_features" name='features' onChange={handleChange}/>
                </div>

                <div className="mb-5">
                    <label htmlFor="product_brand" className="form-label">Brand</label>
                    <input type="text" className="form-control" id="product_brand" name='brand' value={product.brand} onChange={handleChange}/>
                </div>

                <select className="form-select mb-4" aria-label="Product Category" id='category' onChange={handleCategory} name='category' value={`${category.category.category_id}_${category.category.category_name}`}>
                    <option selected value={""} key={12345}>Select Product Category</option>
                    {
                        warehouse.categories.map((category: any) => <option value={`${category.category_id}_${category.category_name}`} key={category.category_id}>{category.category_name}</option>)
                    }
                </select>

                {
                    subCategories.length > 0 &&
                    <select className="form-select mb-4" aria-label="Product Sub-Category" disabled={subCategories.length <= 0} onChange={handleCategory} name='sub_category' value={`${category.sub_category.category_id}_${category.sub_category.sub_category_name}`}>
                        <option selected value={""} key={123456}>Sub-Category</option>
                        {
                            subCategories.map((category: any) => <option value={`${category.category_id}_${category.sub_category_name}`} key={category.category_id}>{category.sub_category_name}</option>)
                        }
                    </select>
                }

                <Button variant="contained" type='submit'>Submit</Button>
            </form>
        </div>
    )
}

export default AddProduct