const { Product } = require("../../database/model");

const edit = async (data) => {
    const id = data.id;
    delete data["_id"];
    await Product.updateOne({ _id: id }, {$set: data});
    return
}

module.exports = { edit }