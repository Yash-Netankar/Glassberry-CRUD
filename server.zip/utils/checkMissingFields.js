function CheckMissingFields(requiredFields, payload) {
  const missingFields = [];

  for(let key of requiredFields){
    if(!(payload.hasOwnProperty(key)) || !(payload[key])){
        missingFields.push(key);
    }
  }

  if(missingFields.length > 0){
    return missingFields
  }
}

module.exports = {CheckMissingFields}