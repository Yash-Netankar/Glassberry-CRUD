const ApiHTTPResponse = require("../../utils/httpResponse");
const { CheckMissingFields } = require("../../utils/checkMissingFields");
const { add } = require("../../actions/Products/add");
const { default: mongoose } = require("mongoose");


const AddProduct = async(req, res) => {
    try {
        const requiredFields = ["name", "description", "features", "category", "sub_category"];
        const checkRes = CheckMissingFields(requiredFields, req.body.data);
        if (checkRes) {
            const response = ApiHTTPResponse(400, [], `${checkRes.join(",")} missing`);
            return res.status(400).json(response);
        }

        const productId = await add(req.body.data);
        const response = ApiHTTPResponse(201, {productId}, "Product added successfuly");
        return res.status(201).json(response);
    }
    catch (error) {
        console.log(error.message);
        const response = ApiHTTPResponse(500, [], "Failed to add this product. Unexpected error occurred");
        return res.status(500).json(response);
    }
}

module.exports = {AddProduct}