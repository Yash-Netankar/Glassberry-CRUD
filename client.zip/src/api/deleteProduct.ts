import {url} from '../utils/Urls';
import axios from 'axios'

export const deleteProduct = async(id: any) => {
  try {
    const res = await axios.delete(`${url.deleteProduct}/${id}`);
    return res.data.data
  }
  catch (error) {
    console.log(error)
  }
}

