const warehouse: any = {
    name: "glassberry warehouse",
    metadata: "",

    products: [],

    categories: [
        {
            category_id: "beauty",
            category_name: "Beauty & Cosmetics",
            sub_categories: [
                {
                    category_id: "organic",
                    sub_category_name: "Organic"
                },
                {
                    category_id: "inorganic",
                    sub_category_name: "Inorganic"
                },
                {
                    category_id: "oily",
                    sub_category_name: "Oily Skin"
                },
                {
                    category_id: "dry",
                    sub_category_name: "Dry Skin"
                },
                {
                    category_id: "all",
                    sub_category_name: "All skin types"
                }
            ]
        },
        {
            category_id: "car",
            category_name: "Cars",
            sub_categories: [
                {
                    category_id: "racing",
                    sub_category_name: "Racing cars"
                },
                {
                    category_id: "commute",
                    sub_category_name: "Daily Commute Cars"
                },
                {
                    category_id: "suv",
                    sub_category_name: "SUV"
                },
                {
                    category_id: "luxury",
                    sub_category_name: "Luxirous cars"
                },
            ]
        },
        {
            category_id: "bike",
            category_name: "Bikes",
            sub_categories: [
                {
                    category_id: "racing",
                    sub_category_name: "Racing Bikes"
                },
                {
                    category_id: "commute",
                    sub_category_name: "Daily Commute Bikes"
                },
                {
                    category_id: "offroad",
                    sub_category_name: "Off Road Bikes"
                },
                {
                    category_id: "ground_clearance",
                    sub_category_name: "High Ground Clearance"
                },
                {
                    category_id: "bullet",
                    sub_category_name: "Bullets"
                },
                {
                    category_id: "cruiser",
                    sub_category_name: "Cruisers"
                },
            ]
        },
        {},
        {}
    ]
}

export default warehouse