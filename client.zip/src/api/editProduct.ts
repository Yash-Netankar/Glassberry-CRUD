import {url} from '../utils/Urls';
import axios from 'axios'

const editProduct = async(data: any) => {
  try {
    const res = await axios.patch(url.editProduct, {data})
    return res.data
  }
  catch (error) {
    console.log(error)
  }
}

export default editProduct