const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const connectDb = require("./database/db");
const cookie_parser = require("cookie-parser")
const ProductRoutes = require("./routes/ProductRoutes");
const { router } = require("./routes/PresignedUrl");
const PORT = process.env.PORT || 5000

const app = express();
dotenv.config();
app.use(cors());
app.use(express.json());
app.use(cookie_parser());

// routes
app.use("/product", ProductRoutes);
app.use("/s3", router);

// test
app.get("/", (req, res) => {
    res.send("<h5 style={{textAlign:'center'}}>Hello from server</h5>");
})

// run
app.listen(PORT, (err) => {
    if(err) process.exit(1)
    console.log("Server listning to port ", PORT);
    connectDb();
})